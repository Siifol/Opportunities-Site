OPPORTUNITIES.COM — V2 STARTER PACKAGE
This version supports Jobs, Scholarships, and Other Opportunities (fellowships, internships, grants and training) with English/Amharic switching, search and category/location filters.

IMPORTANT:
- All 8 listings are fictional demonstrations, not real vacancies.
- Replace demo listings with verified opportunities before public launch.
- The current buttons do not submit applications. They display a notice because no official application URLs or secure backend have been configured.
- Do not add CVs, personal information, API keys or passwords to public HTML/JavaScript.
- For direct applications, configure a secure backend or reputable form service with access control, spam protection, privacy notice and data deletion/retention rules.
- Confirm domain and brand availability. This package does not register opportunities.com.

PUBLISH VIA CLOUDFLARE PAGES:
1. Download and extract this ZIP.
2. Open https://dash.cloudflare.com/ and sign in.
3. Open Workers & Pages, create a Pages project, and choose Direct Upload if available.
4. Upload the extracted folder containing index.html (or upload assets as requested by the dashboard).
5. Deploy and test the supplied *.pages.dev URL.
If direct upload is unavailable on your phone, create a GitHub repository and connect it to Cloudflare Pages using the official setup guide.

MONETIZATION:
- Start with useful, verified, original listings.
- Add About, Contact, Privacy and report-listing processes.
- Apply to an ad network only when the website meets its current eligibility and content policies.
- Offer clearly labelled sponsored listings only after building real traffic and employer trust.
- Never buy fake traffic or encourage ad clicks.
